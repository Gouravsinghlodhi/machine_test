'use strict';
module.exports = {
  hashRound: 10
};
