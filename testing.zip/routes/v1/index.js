
const authRouter = require('./auth');
const userRouter = require('./users');

const categoryRouter = require('./category');
const serviesRouter = require('./servies');


module.exports = {

  authRouter,
  userRouter,
  categoryRouter,
  serviesRouter,

};
